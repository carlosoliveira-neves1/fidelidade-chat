# Backend - Fidelidade CDC (moderno)
- Rodar local em SQLite por padrão.
- Seed cria lojas fixas e usuários exemplo.
