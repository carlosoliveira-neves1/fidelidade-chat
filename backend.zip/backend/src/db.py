import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session, declarative_base

# ---- Lê variáveis simples (Render) ----
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT", "5432")
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASSWORD = os.getenv("DB_PASSWORD")
DATABASE_SCHEMA = os.getenv("DATABASE_SCHEMA")

# ---- Monta DATABASE_URL a partir de DB_* se não vier pronta ----
DATABASE_URL = os.getenv("DATABASE_URL")
if not DATABASE_URL and DB_HOST and DB_NAME and DB_USER and DB_PASSWORD:
    DATABASE_URL = (
        f"postgresql+psycopg2://{DB_USER}:{DB_PASSWORD}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    )

# ---- Fallback local (sqlite) quando nada definido ----
connect_args = {}
if not DATABASE_URL:
    DATABASE_URL = "sqlite:///db.sqlite3"
else:
    # Se Postgres e tiver schema, aplica search_path
    if DATABASE_SCHEMA:
        connect_args = {"options": f"-csearch_path={DATABASE_SCHEMA}"}

engine = create_engine(
    DATABASE_URL, future=True, echo=False, connect_args=connect_args
)
SessionLocal = scoped_session(
    sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
)
Base = declarative_base()
