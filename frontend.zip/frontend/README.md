# Frontend - Fidelidade CDC (moderno)
- Sidebar, tema claro (vinho/dourado), tipografia Inter.
