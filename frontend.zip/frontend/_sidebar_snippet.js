// Exemplo: renderize o item "Admin" apenas para ADMIN
// if (user?.role === 'ADMIN') { render <NavLink to="/admin">Admin</NavLink> }
